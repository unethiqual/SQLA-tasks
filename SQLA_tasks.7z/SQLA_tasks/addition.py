from data import db_session
from data.jobs import Jobs
from data.users import User

db_session.global_init("db/space.db")
db_sess = db_session.create_session()

user1 = User()
user1.surname = "Петров"
user1.name = "Иван"
user1.age = 25
user1.position = "Инженер"
user1.speciality = "Программист"
user1.address = "Москва"
user1.email = "petrov@mail.ru"

user2 = User()
user2.surname = "Иванов"
user2.name = "Петр"
user2.age = 30
user2.position = "Старший инженер"
user2.speciality = "Аналитик"
user2.address = "Санкт-Петербург"
user2.email = "ivanov@mail.ru"

user3 = User()
user3.surname = "Сидоров"
user3.name = "Алексей"
user3.age = 28
user3.position = "Младший инженер"
user3.speciality = "Тестировщик"
user3.address = "Казань"
user3.email = "sidorov@mail.ru"

user4 = User()
user4.surname = "Козлов"
user4.name = "Дмитрий"
user4.age = 35
user4.position = "Ведущий специалист"
user4.speciality = "Архитектор"
user4.address = "Новосибирск"
user4.email = "kozlov@mail.ru"

user5 = User()
user5.surname = "Смирнов"
user5.name = "Михаил"
user5.age = 27
user5.position = "Разработчик"
user5.speciality = "Frontend"
user5.address = "Екатеринбург"
user5.email = "smirnov@mail.ru"

job1 = Jobs()
job1.team_leader = 1
job1.job = "Deployment of residential modules 1 and 2"
job1.work_size = 15
job1.collaborators = "2, 3"
job1.is_finished = False

job2 = Jobs()
job2.team_leader = 2
job2.job = "Exploration of mineral resources"
job2.work_size = 20
job2.collaborators = "4, 5"
job2.is_finished = False

job3 = Jobs()
job3.team_leader = 3
job3.job = "Development of management system"
job3.work_size = 25
job3.collaborators = "1, 5"
job3.is_finished = False

db_sess.add(user1)
db_sess.add(user2)
db_sess.add(user3)
db_sess.add(user4)
db_sess.add(user5)
db_sess.add(job1)
db_sess.add(job2)
db_sess.add(job3)

db_sess.commit()
